<div class="well">
  <?php dynamic_sidebar('roots-sidebar'); ?>
</div>